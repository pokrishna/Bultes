from django.apps import AppConfig


class HomeautomationConfig(AppConfig):
    name = 'HomeAutomation'
